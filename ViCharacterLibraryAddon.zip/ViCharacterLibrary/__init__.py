bl_info = {
    "name": "Vi Character Library",
    "author": "Vi",
    "version": (0, 4, 1),
    "blender": (4, 4, 3),
    "category": "Object",
}

import importlib

from . import core
from . import presets

modules = (
    core,
    presets,
)


def register():
    for module in modules:
        importlib.reload(module)
        module.register()


def unregister():
    for module in reversed(modules):
        module.unregister()
